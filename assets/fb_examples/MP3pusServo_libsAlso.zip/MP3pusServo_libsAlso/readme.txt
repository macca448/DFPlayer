Put the two libraries in "%USERPROFILE%\Documents\Arduino\libraries" folder

Put the Open the sketch in the Arduino IDE

Check the pins are correct

Compile and upload