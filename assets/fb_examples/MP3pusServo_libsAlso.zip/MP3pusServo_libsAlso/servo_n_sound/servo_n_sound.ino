#include <SoftwareSerial.h>
#include <DFPlayer.h>
#include <ServoTimer2.h>

//Pins
#define BTN1   3
#define BTN2   2
#define LED1   5
#define LED2   6
#define SERVO1 9
#define SS_TX 10
#define SS_RX 11

//Constants
#define MP3_SERIAL_SPEED    9600             //DFPlayer Mini suport only 9600-baud
#define MP3_SERIAL_TIMEOUT  350              //average DFPlayer response timeout 200msec..300msec for YX5200/AAxxxx chip & 350msec..500msec for GD3200B/MH2024K chip
#define OPEN                MAX_PULSE_WIDTH  //from library default 2400uS or servo OPEN
#define CLOSED              MIN_PULSE_WIDTH  //from library default  550uS or servo CLOSED
#define LONG_PRESS_TIME     1000UL           //duration that triggers a long press on button2


// State variables
bool servoOpen = false, isPaused = false, button2Press = false, button1Press = false, 
     lastButton1State = HIGH, lastButton2State = HIGH;

uint16_t trackNumber = 3;

// Timing for long press detection and Button de-bounce
uint32_t button2PressTime = 0,  button2PressDuration = 0, buttonPressTime;

// Component Objects
ServoTimer2 servo1;
SoftwareSerial mp3Serial(SS_RX, SS_TX);      // RX, TX
DFPlayer mp3;

void setup() {
  // Init Software Serial
  mp3Serial.begin(9600);                      //Start the Software Serial
  // Setup pins
  pinMode(BTN1, INPUT_PULLUP);                //Set Button1 as Active LOW
  pinMode(BTN2, INPUT_PULLUP);                //Set Button2 as Active LOW
  pinMode(LED1, OUTPUT);
  pinMode(LED2, OUTPUT);
  digitalWrite(LED1, HIGH);                   //LED1 ON as the servo is closed
  digitalWrite(LED2, LOW);
  // Attach servo
  servo1.attach(SERVO1);                      //Attach sero to its pin
  servo1.write(CLOSED);                       //Set servo to start pos
  delay(300);
  // Init DFPlayer
  mp3.begin(mp3Serial, MP3_SERIAL_TIMEOUT, DFPLAYER_MINI, false); // Should be the Generic DFplayer
  //mp3.begin(mp3Serial, MP3_SERIAL_TIMEOUT, DFPLAYER_MP3_TF_16P, false); //"DFPLAYER_HW_247A" see NOTE, false=no feedback from module after the command
  delay(300);
  mp3.stop();                             //if player was runing during reboot
  delay(300);
  //mp3.reset();                            //reset all setting to default 
  //mp3.setSource(2);                       //1=USB-Disk, 2=TF-Card, 3=Aux, 4=Sleep, 5=NOR Flash
  //mp3.setEQ(0);                           //0=Off, 1=Pop, 2=Rock, 3=Jazz, 4=Classic, 5=Bass
  mp3.setVolume(30);                      //0..30, module persists volume on power failure
  delay(300);
}

void loop() {
  uint32_t currentMillis = millis();
  
  // === BUTTON 1: Toggle servo + LED + File 1 or 2 ===
  bool button1State = digitalRead(BTN1);            // Read button1 state
  if(!button2Press){                                       // So only one button is read at a time
    if (button1State != lastButton1State) {               // Watch for state change
      buttonPressTime = currentMillis;                    // Set debounce timer
      button1Press = true;                                // Button1 Press flag
    }
  }

  // === BUTTON 2: File select (short press) OR pause/resume (long press) ===
  bool button2State = digitalRead(BTN2);            // Read button2 state
  if(!button1Press){                                       // So only one button is read at a time
    if (button2State != lastButton2State) {               // Watch for state change
      buttonPressTime = currentMillis;                    // Set debounce timer
      button2Press = true;                                // Button2 Press flag
    }
  }

  //Button deBounce statement holds both button actions
  if(currentMillis - buttonPressTime >= 50){
    // === BUTTON 1: Toggle servo + LED + File 1 or 2 ===
    if(button1Press){                                    // True on button1 press
      if(digitalRead(BTN1) == LOW){                      // Check state after debounce
        if (servoOpen) {                                 // True when servo is in closed position
          servoOpen = false;                             // So next press closes servo
          mp3.playTrack(2);                              // Play file 2 
          delay(300);                                    // Wait for serial command to finish
          servo1.write(OPEN);                            // Move servo to OPEN position
          digitalWrite(LED1, LOW);
          digitalWrite(LED2, HIGH);
        } else {                                         // True when servo is in open position
          servoOpen = true;                              // So next press opens servo
          mp3.playTrack(1);                              // Play file 1
          delay(300);                                    // Wait for serial command to finish
          servo1.write(CLOSED);                          // Move servo to CLOSED position
          digitalWrite(LED1, HIGH);
          digitalWrite(LED2, LOW);
        }
      }
      button1Press = false;                              // Set press flag off for next press
    }

    // === BUTTON 2: File select (short press) OR pause/resume (long press) ===
    if(button2Press){
      if(digitalRead(BTN2) == LOW){        // button2 is pressed
        button2PressTime = currentMillis;
      } else {                             // button is released
        unsigned long button2PressDuration = currentMillis - button2PressTime; // Calculate press duration
        if( button2PressDuration >= LONG_PRESS_TIME ){           // If less than 1 second a short press
          // Long press
          if (isPaused) {
            mp3.resume();
            isPaused = false;
          } else {
            mp3.pause();
            isPaused = true;
          }
          delay(300);
        }else{                                                  // When longer than 1 second  its a long press
          // Short press
          mp3.playTrack(trackNumber);
          delay(300);
          trackNumber++;
          if (trackNumber > 12) {
            trackNumber = 3;
          }
        }
      }
      button2Press = false;
    }
  } //millis END

  lastButton1State = button1State;
  lastButton2State = button2State;
}
